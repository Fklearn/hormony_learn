package com.sensorsdata.analytics.harmony.sdk.common.constant;

public interface ThreadNameConstants {
    String THREAD_TASK_QUEUE = "SA.TaskQueueThread";
}
