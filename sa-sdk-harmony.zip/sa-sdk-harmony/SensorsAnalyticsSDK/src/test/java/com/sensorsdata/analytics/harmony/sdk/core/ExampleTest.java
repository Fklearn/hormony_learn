package com.sensorsdata.analytics.harmony.sdk.core;

import org.junit.Test;

public class ExampleTest {
    @Test
    public void onStart() {
    }
}
