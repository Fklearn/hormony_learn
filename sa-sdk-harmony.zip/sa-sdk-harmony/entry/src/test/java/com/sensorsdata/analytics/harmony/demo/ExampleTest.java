package com.sensorsdata.analytics.harmony.demo;

import org.junit.Test;

public class ExampleTest {
    @Test
    public void onStart() {
    }
}
