import router from '@ohos:router';
class Home extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.__currentTabIndex = new ObservedPropertySimplePU(0, this, "currentTabIndex");
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.currentTabIndex !== undefined) {
            this.currentTabIndex = params.currentTabIndex;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__currentTabIndex.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__currentTabIndex.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    get currentTabIndex() {
        return this.__currentTabIndex.get();
    }
    set currentTabIndex(newValue) {
        this.__currentTabIndex.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Tabs.create();
            Tabs.debugLine("pages/Home.ets(8:5)");
            Tabs.barPosition(BarPosition.End);
            Tabs.onChange((index) => {
                this.currentTabIndex = index;
            });
            if (!isInitialRender) {
                Tabs.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            TabContent.create(() => {
                {
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        if (isInitialRender) {
                            ViewPU.create(new Foods(this, {}, undefined, elmtId));
                        }
                        else {
                            this.updateStateVarsOfChildByElmtId(elmtId, {});
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                }
            });
            TabContent.tabBar({ builder: () => {
                    this.bar.call(this, '主页', { "id": 16777230, "type": 20000, params: [], "bundleName": "com.example.healthydiet", "moduleName": "entry" }, 0);
                } });
            TabContent.debugLine("pages/Home.ets(9:7)");
            if (!isInitialRender) {
                TabContent.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        TabContent.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            TabContent.create(() => {
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    Column.create({ space: 10 });
                    Column.debugLine("pages/Home.ets(14:9)");
                    Column.padding(30);
                    Column.alignItems(HorizontalAlign.Center);
                    if (!isInitialRender) {
                        Column.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    Text.create("敬请期待第二季");
                    Text.debugLine("pages/Home.ets(16:11)");
                    Text.fontSize(26);
                    Text.fontColor(0x3E3E3E);
                    if (!isInitialRender) {
                        Text.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                Text.pop();
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    Text.create("实战开发教程，会实现全部功能。");
                    Text.debugLine("pages/Home.ets(17:11)");
                    Text.fontSize(18);
                    Text.fontColor(0x3E3E3E);
                    if (!isInitialRender) {
                        Text.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                Text.pop();
                Column.pop();
            });
            TabContent.tabBar({ builder: () => {
                    this.bar.call(this, '记录', { "id": 16777231, "type": 20000, params: [], "bundleName": "com.example.healthydiet", "moduleName": "entry" }, 1);
                } });
            TabContent.debugLine("pages/Home.ets(13:7)");
            if (!isInitialRender) {
                TabContent.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        TabContent.pop();
        Tabs.pop();
    }
    bar(name, icon, index, parent = null) {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Flex.create({
                direction: FlexDirection.Column,
                alignItems: ItemAlign.Center,
                justifyContent: FlexAlign.Center
            });
            Flex.debugLine("pages/Home.ets(32:5)");
            if (!isInitialRender) {
                Flex.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create(icon);
            Image.debugLine("pages/Home.ets(37:7)");
            Image.width(24);
            Image.height(24);
            Image.fillColor(this.currentTabIndex === index ? '#55ff55' : '');
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(name);
            Text.debugLine("pages/Home.ets(41:7)");
            Text.fontSize(11);
            Text.fontColor(0x3E3E3E);
            Text.margin(10);
            Text.fontColor(this.currentTabIndex === index ? '#55ff55' : '');
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Flex.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
class Foods extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.__currentTabIndex = new ObservedPropertySimplePU(0, this, "currentTabIndex");
        this.categories = [{ id: 1, name: '蔬菜' }, { id: 2, name: '水果' }, { id: 3, name: '坚果' }, { id: 4, name: '海鲜' }];
        this.foods = [
            {
                id: 0,
                name: '番茄',
                kk: 15,
                category: 1,
                img: { "id": 16777232, "type": 20000, params: [], "bundleName": "com.example.healthydiet", "moduleName": "entry" },
                rl: 0,
                yy: 0,
                zf: 0
            },
            {
                id: 1,
                name: '核桃',
                kk: 646,
                category: 3,
                img: { "id": 16777241, "type": 20000, params: [], "bundleName": "com.example.healthydiet", "moduleName": "entry" },
                rl: 0,
                yy: 0,
                zf: 0
            },
            {
                id: 2,
                name: '黄瓜',
                kk: 16,
                category: 2,
                img: { "id": 16777226, "type": 20000, params: [], "bundleName": "com.example.healthydiet", "moduleName": "entry" },
                rl: 0,
                yy: 0,
                zf: 0
            },
            {
                id: 3,
                name: '蓝莓',
                kk: 57,
                category: 2,
                img: { "id": 16777235, "type": 20000, params: [], "bundleName": "com.example.healthydiet", "moduleName": "entry" },
                rl: 0,
                yy: 0,
                zf: 0
            },
            {
                id: 4,
                name: '螃蟹',
                kk: 97,
                category: 4,
                img: { "id": 16777222, "type": 20000, params: [], "bundleName": "com.example.healthydiet", "moduleName": "entry" },
                rl: 0,
                yy: 0,
                zf: 0
            },
            {
                id: 5,
                name: '冰淇淋',
                kk: 150,
                category: 5,
                img: { "id": 16777225, "type": 20000, params: [], "bundleName": "com.example.healthydiet", "moduleName": "entry" },
                rl: 0,
                yy: 0,
                zf: 0
            },
            {
                id: 6,
                name: '洋葱',
                kk: 40,
                category: 1,
                img: { "id": 16777236, "type": 20000, params: [], "bundleName": "com.example.healthydiet", "moduleName": "entry" },
                rl: 0,
                yy: 0,
                zf: 0
            },
            {
                id: 7,
                name: '蘑菇',
                kk: 20,
                category: 1,
                img: { "id": 16777234, "type": 20000, params: [], "bundleName": "com.example.healthydiet", "moduleName": "entry" },
                rl: 0,
                yy: 0,
                zf: 0
            },
            {
                id: 8,
                name: '猕猴桃',
                kk: 61,
                category: 2,
                img: { "id": 16777239, "type": 20000, params: [], "bundleName": "com.example.healthydiet", "moduleName": "entry" },
                rl: 0,
                yy: 0,
                zf: 0
            },
            {
                id: 9,
                name: '火龙果',
                kk: 55,
                category: 2,
                img: { "id": 16777223, "type": 20000, params: [], "bundleName": "com.example.healthydiet", "moduleName": "entry" },
                rl: 0,
                yy: 0,
                zf: 0
            },
            {
                id: 10,
                name: '草莓',
                kk: 32,
                category: 2,
                img: { "id": 16777227, "type": 20000, params: [], "bundleName": "com.example.healthydiet", "moduleName": "entry" },
                rl: 0,
                yy: 0,
                zf: 0
            },
            {
                id: 11,
                name: '牛油果',
                kk: 171,
                category: 2,
                img: { "id": 16777238, "type": 20000, params: [], "bundleName": "com.example.healthydiet", "moduleName": "entry" },
                rl: 0,
                yy: 0,
                zf: 0
            },
        ];
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.currentTabIndex !== undefined) {
            this.currentTabIndex = params.currentTabIndex;
        }
        if (params.categories !== undefined) {
            this.categories = params.categories;
        }
        if (params.foods !== undefined) {
            this.foods = params.foods;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__currentTabIndex.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__currentTabIndex.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    get currentTabIndex() {
        return this.__currentTabIndex.get();
    }
    set currentTabIndex(newValue) {
        this.__currentTabIndex.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Tabs.create();
            Tabs.debugLine("pages/Home.ets(174:5)");
            Tabs.width('90%');
            Tabs.padding({ bottom: 20 });
            Tabs.onChange((index) => {
                this.currentTabIndex = index;
            });
            if (!isInitialRender) {
                Tabs.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            TabContent.create(() => {
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    Grid.create();
                    Grid.debugLine("pages/Home.ets(176:9)");
                    Grid.columnsTemplate('1fr 1fr');
                    Grid.rowsGap(10);
                    Grid.columnsGap(10);
                    if (!isInitialRender) {
                        Grid.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    ForEach.create();
                    const forEachItemGenFunction = (_item, index) => {
                        const item = _item;
                        {
                            const isLazyCreate = true && (Grid.willUseProxy() === true);
                            const itemCreation = (elmtId, isInitialRender) => {
                                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                                GridItem.create(deepRenderFunction, isLazyCreate);
                                GridItem.debugLine("pages/Home.ets(178:13)");
                                if (!isInitialRender) {
                                    GridItem.pop();
                                }
                                ViewStackProcessor.StopGetAccessRecording();
                            };
                            const observedShallowRender = () => {
                                this.observeComponentCreation(itemCreation);
                                GridItem.pop();
                            };
                            const observedDeepRender = () => {
                                this.observeComponentCreation(itemCreation);
                                {
                                    this.observeComponentCreation((elmtId, isInitialRender) => {
                                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                                        if (isInitialRender) {
                                            ViewPU.create(new FoodItem(this, { food: item }, undefined, elmtId));
                                        }
                                        else {
                                            this.updateStateVarsOfChildByElmtId(elmtId, {});
                                        }
                                        ViewStackProcessor.StopGetAccessRecording();
                                    });
                                }
                                GridItem.pop();
                            };
                            const deepRenderFunction = (elmtId, isInitialRender) => {
                                itemCreation(elmtId, isInitialRender);
                                this.updateFuncByElmtId.set(elmtId, itemCreation);
                                {
                                    this.observeComponentCreation((elmtId, isInitialRender) => {
                                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                                        if (isInitialRender) {
                                            ViewPU.create(new FoodItem(this, { food: item }, undefined, elmtId));
                                        }
                                        else {
                                            this.updateStateVarsOfChildByElmtId(elmtId, {});
                                        }
                                        ViewStackProcessor.StopGetAccessRecording();
                                    });
                                }
                                GridItem.pop();
                            };
                            if (isLazyCreate) {
                                observedShallowRender();
                            }
                            else {
                                observedDeepRender();
                            }
                        }
                    };
                    this.forEachUpdateFunction(elmtId, this.foods, forEachItemGenFunction, undefined, true, false);
                    if (!isInitialRender) {
                        ForEach.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                ForEach.pop();
                Grid.pop();
            });
            TabContent.tabBar({ builder: () => {
                    this.bar.call(this, '所有', 0);
                } });
            TabContent.debugLine("pages/Home.ets(175:7)");
            if (!isInitialRender) {
                TabContent.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        TabContent.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            ForEach.create();
            const forEachItemGenFunction = (_item, index) => {
                const item = _item;
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    TabContent.create(() => {
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            Grid.create();
                            Grid.debugLine("pages/Home.ets(191:11)");
                            Grid.columnsTemplate('1fr 1fr');
                            Grid.rowsGap(10);
                            Grid.columnsGap(10);
                            if (!isInitialRender) {
                                Grid.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            ForEach.create();
                            const forEachItemGenFunction = (_item, index) => {
                                const item = _item;
                                {
                                    const isLazyCreate = true && (Grid.willUseProxy() === true);
                                    const itemCreation = (elmtId, isInitialRender) => {
                                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                                        GridItem.create(deepRenderFunction, isLazyCreate);
                                        GridItem.debugLine("pages/Home.ets(193:15)");
                                        if (!isInitialRender) {
                                            GridItem.pop();
                                        }
                                        ViewStackProcessor.StopGetAccessRecording();
                                    };
                                    const observedShallowRender = () => {
                                        this.observeComponentCreation(itemCreation);
                                        GridItem.pop();
                                    };
                                    const observedDeepRender = () => {
                                        this.observeComponentCreation(itemCreation);
                                        {
                                            this.observeComponentCreation((elmtId, isInitialRender) => {
                                                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                                                if (isInitialRender) {
                                                    ViewPU.create(new FoodItem(this, { food: item }, undefined, elmtId));
                                                }
                                                else {
                                                    this.updateStateVarsOfChildByElmtId(elmtId, {});
                                                }
                                                ViewStackProcessor.StopGetAccessRecording();
                                            });
                                        }
                                        GridItem.pop();
                                    };
                                    const deepRenderFunction = (elmtId, isInitialRender) => {
                                        itemCreation(elmtId, isInitialRender);
                                        this.updateFuncByElmtId.set(elmtId, itemCreation);
                                        {
                                            this.observeComponentCreation((elmtId, isInitialRender) => {
                                                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                                                if (isInitialRender) {
                                                    ViewPU.create(new FoodItem(this, { food: item }, undefined, elmtId));
                                                }
                                                else {
                                                    this.updateStateVarsOfChildByElmtId(elmtId, {});
                                                }
                                                ViewStackProcessor.StopGetAccessRecording();
                                            });
                                        }
                                        GridItem.pop();
                                    };
                                    if (isLazyCreate) {
                                        observedShallowRender();
                                    }
                                    else {
                                        observedDeepRender();
                                    }
                                }
                            };
                            this.forEachUpdateFunction(elmtId, this.foods.filter(food => food.category === this.currentTabIndex), forEachItemGenFunction, undefined, true, false);
                            if (!isInitialRender) {
                                ForEach.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        ForEach.pop();
                        Grid.pop();
                    });
                    TabContent.tabBar({ builder: () => {
                            this.bar.call(this, item.name, item.id);
                        } });
                    TabContent.debugLine("pages/Home.ets(190:9)");
                    if (!isInitialRender) {
                        TabContent.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                TabContent.pop();
            };
            this.forEachUpdateFunction(elmtId, this.categories, forEachItemGenFunction, undefined, true, false);
            if (!isInitialRender) {
                ForEach.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        ForEach.pop();
        Tabs.pop();
    }
    bar(name, index, parent = null) {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Flex.create({
                direction: FlexDirection.Column,
                alignItems: ItemAlign.Center,
                justifyContent: FlexAlign.Center
            });
            Flex.debugLine("pages/Home.ets(214:5)");
            if (!isInitialRender) {
                Flex.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(name);
            Text.debugLine("pages/Home.ets(219:7)");
            Text.fontSize(this.currentTabIndex === index ? 20 : 14);
            Text.fontColor(0x3E3E3E);
            Text.margin(10);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Flex.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
class FoodItem extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.food = undefined;
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.food !== undefined) {
            this.food = params.food;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("pages/Home.ets(228:5)");
            Column.clip(new Rect({ width: '100%', height: '100%', radius: 6 }));
            Column.onClick(() => {
                console.log(JSON.stringify(this.food));
                router.pushUrl({
                    url: 'pages/Detail',
                    params: {
                        foodInfo: this.food
                    }
                });
            });
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create(this.food.img);
            Image.debugLine("pages/Home.ets(229:7)");
            Image.width('100%');
            Image.height(152);
            Image.backgroundColor('#f1f3f5');
            Image.objectFit(ImageFit.Contain);
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/Home.ets(230:7)");
            Row.width('100%');
            Row.height(32);
            Row.backgroundColor('#e5e5e5');
            Row.padding({ left: 12, right: 12 });
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(this.food.name);
            Text.debugLine("pages/Home.ets(231:9)");
            Text.fontSize(16);
            Text.fontColor(0x3E3E3E);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Blank.create();
            Blank.debugLine("pages/Home.ets(232:9)");
            if (!isInitialRender) {
                Blank.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Blank.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(this.food.kk + ' 千卡');
            Text.debugLine("pages/Home.ets(233:9)");
            Text.fontSize(16);
            Text.fontColor(0x3E3E3E);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Row.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
ViewStackProcessor.StartGetAccessRecordingFor(ViewStackProcessor.AllocateNewElmetIdForNextComponent());
loadDocument(new Home(undefined, {}));
ViewStackProcessor.StopGetAccessRecording();
//# sourceMappingURL=Home.js.map